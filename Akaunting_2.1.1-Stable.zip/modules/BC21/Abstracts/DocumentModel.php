<?php

namespace App\Abstracts;

use App\Models\Document\Document;

/**
 * @deprecated
 * @see Document
 */
abstract class DocumentModel extends Document
{
}
