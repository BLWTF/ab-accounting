<?php

namespace App\Jobs\Banking;

/**
 * @deprecated
 * @see CreateBankingDocumentTransaction
 */
class CreateDocumentTransaction extends CreateBankingDocumentTransaction
{
}
