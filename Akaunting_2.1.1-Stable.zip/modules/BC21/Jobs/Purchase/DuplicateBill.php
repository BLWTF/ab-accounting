<?php

namespace App\Jobs\Purchase;

use App\Jobs\Document\DuplicateDocument;

/**
 * @deprecated
 * @see DuplicateDocument
 */
class DuplicateBill extends DuplicateDocument
{
}
