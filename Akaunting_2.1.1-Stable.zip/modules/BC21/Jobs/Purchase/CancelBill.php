<?php

namespace App\Jobs\Purchase;

use App\Jobs\Document\CancelDocument;

/**
 * @deprecated
 * @see CancelDocument
 */
class CancelBill extends CancelDocument
{
}
