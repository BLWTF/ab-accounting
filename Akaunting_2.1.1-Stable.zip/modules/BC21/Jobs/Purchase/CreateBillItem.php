<?php

namespace App\Jobs\Purchase;

use App\Jobs\Document\CreateDocumentItem;

/**
 * @deprecated
 * @see CreateDocumentItem
 */
class CreateBillItem extends CreateDocumentItem
{
}
