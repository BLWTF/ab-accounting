<?php

namespace App\Jobs\Purchase;

use App\Jobs\Document\UpdateDocument;

/**
 * @deprecated
 * @see UpdateDocument
 */
class UpdateBill extends UpdateDocument
{
}
