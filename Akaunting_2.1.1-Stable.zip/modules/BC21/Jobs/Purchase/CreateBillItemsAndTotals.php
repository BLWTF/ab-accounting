<?php

namespace App\Jobs\Purchase;

use App\Jobs\Document\CreateDocumentItemsAndTotals;

/**
 * @deprecated
 * @see CreateDocumentItemsAndTotals
 */
class CreateBillItemsAndTotals extends CreateDocumentItemsAndTotals
{
}
