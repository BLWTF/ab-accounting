<?php

namespace App\Jobs\Purchase;

use App\Jobs\Document\CreateDocumentHistory;

/**
 * @deprecated
 * @see CreateDocumentHistory
 */
class CreateBillHistory extends CreateDocumentHistory
{
}
