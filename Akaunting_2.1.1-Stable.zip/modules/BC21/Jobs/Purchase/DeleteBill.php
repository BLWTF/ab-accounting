<?php

namespace App\Jobs\Purchase;

use App\Jobs\Document\DeleteDocument;

/**
 * @deprecated
 * @see DeleteDocument
 */
class DeleteBill extends DeleteDocument
{
}
