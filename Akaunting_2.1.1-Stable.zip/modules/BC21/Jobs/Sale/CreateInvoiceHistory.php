<?php

namespace App\Jobs\Sale;

use App\Jobs\Document\CreateDocumentHistory;

/**
 * @deprecated
 * @see CreateDocumentHistory
 */
class CreateInvoiceHistory extends CreateDocumentHistory
{
}
