<?php

namespace App\Jobs\Sale;

use App\Jobs\Document\CreateDocumentItemsAndTotals;

/**
 * @deprecated
 * @see CreateDocumentItemsAndTotals
 */
class CreateInvoiceItemsAndTotals extends CreateDocumentItemsAndTotals
{
}
