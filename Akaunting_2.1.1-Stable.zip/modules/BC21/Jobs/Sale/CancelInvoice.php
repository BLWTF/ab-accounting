<?php

namespace App\Jobs\Sale;

use App\Jobs\Document\CancelDocument;

/**
 * @deprecated
 * @see CancelDocument
 */
class CancelInvoice extends CancelDocument
{
}
