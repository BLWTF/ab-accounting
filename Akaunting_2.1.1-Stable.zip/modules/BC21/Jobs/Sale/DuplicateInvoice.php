<?php

namespace App\Jobs\Sale;

use App\Jobs\Document\DuplicateDocument;

/**
 * @deprecated
 * @see DuplicateDocument
 */
class DuplicateInvoice extends DuplicateDocument
{
}
