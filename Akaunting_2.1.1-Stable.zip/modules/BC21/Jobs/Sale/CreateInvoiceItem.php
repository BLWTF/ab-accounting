<?php

namespace App\Jobs\Sale;

use App\Jobs\Document\CreateDocumentItem;

/**
 * @deprecated
 * @see CreateDocumentItem
 */
class CreateInvoiceItem extends CreateDocumentItem
{
}
