<?php

namespace App\Jobs\Sale;

use App\Jobs\Document\UpdateDocument;

/**
 * @deprecated
 * @see UpdateDocument
 */
class UpdateInvoice extends UpdateDocument
{
}
