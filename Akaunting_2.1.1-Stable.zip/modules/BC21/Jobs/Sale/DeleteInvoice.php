<?php

namespace App\Jobs\Sale;

use App\Jobs\Document\DeleteDocument;

/**
 * @deprecated
 * @see DeleteDocument
 */
class DeleteInvoice extends DeleteDocument
{
}
