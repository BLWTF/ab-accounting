<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentCreating;

/**
 * @deprecated
 * @see DocumentCreating
 */
class InvoiceCreating extends DocumentCreating
{
}
