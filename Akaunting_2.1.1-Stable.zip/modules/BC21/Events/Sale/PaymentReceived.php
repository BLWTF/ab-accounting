<?php

namespace App\Events\Sale;

class PaymentReceived extends \App\Events\Document\PaymentReceived
{
}
