<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentViewed;

/**
 * @deprecated
 * @see DocumentViewed
 */
class InvoiceViewed extends DocumentViewed
{
}
