<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentUpdating;

/**
 * @deprecated
 * @see DocumentUpdating
 */
class InvoiceUpdating extends DocumentUpdating
{
}
