<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentSent;

/**
 * @deprecated
 * @see DocumentSent
 */
class InvoiceSent extends DocumentSent
{
}
