<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentUpdated;

/**
 * @deprecated
 * @see DocumentUpdated
 */
class InvoiceUpdated extends DocumentUpdated
{
}
