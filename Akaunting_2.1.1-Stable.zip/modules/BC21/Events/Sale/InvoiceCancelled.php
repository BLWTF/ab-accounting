<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentCancelled;

/**
 * @deprecated
 * @see DocumentCancelled
 */
class InvoiceCancelled extends DocumentCancelled
{
}
