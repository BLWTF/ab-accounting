<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentRecurring;

/**
 * @deprecated
 * @see DocumentRecurring
 */
class InvoiceRecurring extends DocumentRecurring
{
}
