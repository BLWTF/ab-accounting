<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentCreated;

/**
 * @deprecated
 * @see DocumentCreated
 */
class InvoiceCreated extends DocumentCreated
{
}
