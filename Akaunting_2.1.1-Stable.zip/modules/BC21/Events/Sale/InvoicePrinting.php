<?php

namespace App\Events\Sale;

use App\Events\Document\DocumentPrinting;

/**
 * @deprecated
 * @see DocumentPrinting
 */
class InvoicePrinting extends DocumentPrinting
{
}
