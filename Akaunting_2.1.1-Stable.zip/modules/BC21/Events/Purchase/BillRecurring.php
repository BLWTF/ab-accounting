<?php

namespace App\Events\Purchase;

use App\Events\Document\DocumentRecurring;

/**
 * @deprecated
 * @see DocumentRecurring
 */
class BillRecurring extends DocumentRecurring
{
}
