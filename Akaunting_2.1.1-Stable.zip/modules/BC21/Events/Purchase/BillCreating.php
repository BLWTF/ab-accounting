<?php

namespace App\Events\Purchase;

use App\Events\Document\DocumentCreating;

/**
 * @deprecated
 * @see DocumentCreating
 */
class BillCreating extends DocumentCreating
{
}
