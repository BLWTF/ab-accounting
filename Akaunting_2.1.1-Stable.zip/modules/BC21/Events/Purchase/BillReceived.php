<?php

namespace App\Events\Purchase;

use App\Events\Document\DocumentReceived;

/**
 * @deprecated
 * @see DocumentReceived
 */
class BillReceived extends DocumentReceived
{
}
