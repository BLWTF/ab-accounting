<?php

namespace App\Events\Purchase;

use App\Events\Document\DocumentCreated;

/**
 * @deprecated
 * @see Document
 */
class BillCreated extends DocumentCreated
{
}
