<?php

namespace App\Events\Purchase;

use App\Events\Document\DocumentUpdating;

/**
 * @deprecated
 * @see DocumentUpdating
 */
class BillUpdating extends DocumentUpdating
{
}
