<?php

namespace App\Events\Purchase;

use App\Events\Document\DocumentUpdated;

/**
 * @deprecated
 * @see DocumentUpdated
 */
class BillUpdated extends DocumentUpdated
{
}
