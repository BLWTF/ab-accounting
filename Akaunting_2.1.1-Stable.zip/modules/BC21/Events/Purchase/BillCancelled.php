<?php

namespace App\Events\Purchase;

use App\Events\Document\DocumentCancelled;

/**
 * @deprecated
 * @see DocumentCancelled
 */
class BillCancelled extends DocumentCancelled
{
}
