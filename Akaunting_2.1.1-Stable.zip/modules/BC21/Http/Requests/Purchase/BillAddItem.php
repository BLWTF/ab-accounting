<?php

namespace App\Http\Requests\Purchase;

use App\Http\Requests\Document\DocumentAddItem;

/**
 * @deprecated
 * @see DocumentAddItem
 */
class BillAddItem extends DocumentAddItem
{
}
