<?php

namespace App\Http\Requests\Sale;

use App\Http\Requests\Document\DocumentAddItem;

/**
 * @deprecated
 * @see DocumentAddItem
 */
class InvoiceAddItem extends DocumentAddItem
{
}
