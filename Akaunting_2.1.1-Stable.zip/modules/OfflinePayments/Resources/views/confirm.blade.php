<h2>{{ $setting['name'] }}</h2>

@if ($setting['description'])
    <div class="well well-sm">
        {{ $setting['description'] }}
    </div>
@endif
