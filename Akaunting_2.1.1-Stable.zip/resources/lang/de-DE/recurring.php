<?php

return [

    'recurring'             => 'Wiederkehrend',
    'every'                 => 'Jeden',
    'period'                => 'Zeitraum',
    'times'                 => 'mal',
    'daily'                 => 'Täglich',
    'weekly'                => 'Wöchentlich',
    'monthly'               => 'Monatlich',
    'yearly'                => 'Jährlich',
    'custom'                => 'Benutzerdefiniert',
    'days'                  => 'Tag(e)',
    'weeks'                 => 'Woche(n)',
    'months'                => 'Monat(e)',
    'years'                 => 'Jahr(e)',
    'message'               => 'Dies ist ein(e) sich wiederholende :type und die/der nächste :type wird automatisch am :date erzeugt',

];
