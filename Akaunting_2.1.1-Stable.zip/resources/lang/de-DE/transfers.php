<?php

return [

    'from_account'          => 'Von Konto',
    'to_account'            => 'Auf Konto',

    'messages' => [
        'delete'            => ':from nach :to (:amount)',
    ],

];
