<?php

return [

    'sales_price'           => 'Verkaufspreis',
    'purchase_price'        => 'Einkaufspreis',

];
