<?php

return [

    'account_name'          => 'Konto',
    'number'                => 'Nummer',
    'opening_balance'       => 'Start Guthaben',
    'current_balance'       => 'Aktuelles Guthaben',
    'bank_name'             => 'Bankname',
    'bank_phone'            => 'Bank Telefonnummer',
    'bank_address'          => 'Bank Adresse',
    'default_account'       => 'Standardkonto',

];
