<?php

return [

    'rate'                  => 'Steuersatz',
    'rate_percent'          => 'Steuersatz (%)',
    'normal'                => 'Normal',
    'inclusive'             => 'Inklusive',
    'compound'              => 'zusammengesetzt',
    'fixed'                 => 'Fest',
    'withholding'           => 'Auszahlung',
];
