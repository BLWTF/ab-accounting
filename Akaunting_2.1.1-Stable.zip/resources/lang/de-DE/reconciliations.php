<?php

return [

    'reconcile'             => 'Abstimmen',
    'unreconcile'           => 'Nicht abgeglichen',
    'reconciled'            => 'Abgeglichen',
    'opening_balance'       => 'Eröffnungssaldo',
    'closing_balance'       => 'Endsaldo',
    'unreconciled'          => 'Nicht abgeglichen',
    'transactions'          => 'Transaktionen',
    'start_date'            => 'Startdatum',
    'end_date'              => 'Enddatum',
    'cleared_amount'        => 'Ausgeglichener Betrag',
    'deposit'               => 'Einzahlung',
    'withdrawal'            => 'Auszahlung',

];
