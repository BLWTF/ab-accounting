<?php

return [

    'columns' => [
        'last_logged_in_at' => 'Letzte Anmeldung',
        'paid_at'           => 'Zahlungseingang am',
        'started_at'        => 'Startdatum',
        'ended_at'          => 'Enddatum',
        'billed_at'         => 'Rechnungsdatum',
        'due_at'            => 'Fälligkeitsdatum',
        'invoiced_at'       => 'Rechnungsdatum',
        'issued_at'         => 'Ausstellungsdatum',
        'symbol_first'      => 'Symbolposition',
        'reconciled'        => 'Abgeglichen',
    ],

];
