<?php

return [

    'title' => 'Wartungsarbeiten',

    'message' => 'Entschuldigung, die App ist wegen Wartungsarbeiten nicht verfügbar. Bitte versuchen Sie es später erneut!',

];
