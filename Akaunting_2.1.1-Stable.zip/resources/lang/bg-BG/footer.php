<?php

return [

    'version'               => 'Версия',
    'powered'               => 'С подкрепата на Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Безплатен счетоводен софтуер',

];
