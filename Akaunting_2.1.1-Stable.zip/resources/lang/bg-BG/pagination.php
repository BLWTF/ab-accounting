<?php

return [

    'previous'              => 'Предишен',
    'next'                  => 'Следващ',
    'showing'               => ':first-:last от :total записа.',
    'page'                  => 'на страница.',

];
