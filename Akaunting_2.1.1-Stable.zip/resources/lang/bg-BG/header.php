<?php

return [

    'change_language'       => 'Промяна на езика',
    'last_login'            => 'Последно влизане :time',
    'notifications' => [
        'counter'           => '{0} Нямате известия|{1} Имате :count ново известие|[2,*] Имате :count нови известия',
        'overdue_invoices'  => '{1} :count просрочено вземане|[2,*] :count просрочени вземания',
        'upcoming_bills'    => '{1} :count наближаваща фактура|[2,*] :count наближаващи фактури',
        'view_all'          => 'Вижте всички'
    ],
    'docs_link'             => 'https://akaunting.com/docs',
    'support_link'          => 'https://akaunting.com/support',

];
