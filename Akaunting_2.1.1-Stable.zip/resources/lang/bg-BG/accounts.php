<?php

return [

    'account_name'          => 'Oрганизация',
    'number'                => 'Номер',
    'opening_balance'       => 'Начално салдо',
    'current_balance'       => 'Текущо салдо',
    'bank_name'             => 'Име на банката',
    'bank_phone'            => 'Телефон на банката',
    'bank_address'          => 'Адрес на банката',
    'default_account'       => 'Акаунт по подразбиране',

];
