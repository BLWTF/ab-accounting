<?php

return [

    'sales_price'           => 'Продажна цена',
    'purchase_price'        => 'Покупна цена',

];
