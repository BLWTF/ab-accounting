<?php

return [

    'rate'                  => 'Ставка',
    'rate_percent'          => 'Ставка (%)',
    'normal'                => 'Нормално',
    'inclusive'             => 'Включително',
    'compound'              => 'С натрупване',
    'fixed'                 => 'Фиксиран',
    'withholding'           => 'Удържан',
];
