<?php

return [

    'can_login'             => 'Вход?',
    'user_created'          => 'Създаден потребител',

    'error' => [
        'email'             => 'Този имейл вече е бил регистриран.',
    ],

];
