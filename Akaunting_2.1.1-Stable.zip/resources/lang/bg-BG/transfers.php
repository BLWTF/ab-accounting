<?php

return [

    'from_account'          => 'От сметка',
    'to_account'            => 'Към сметка',

    'messages' => [
        'delete'            => ':from до :to (:amount)',
    ],

];
