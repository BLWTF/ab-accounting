<?php

return [

    'whoops'              => 'Uuups!',
    'hello'               => 'Pozdrav!',
    'salutation'          => 'Pozdrav, <br>:company_name',
    'subcopy'             => 'Ako imate problema s klikom na gumb ":text", kopirajte i zalijepite URL ispod u svoj web preglednik: [:url](:url)',

];
