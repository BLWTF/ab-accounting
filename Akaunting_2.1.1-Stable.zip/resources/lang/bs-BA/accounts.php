<?php

return [

    'account_name'          => 'Naziv računa',
    'number'                => 'Broj',
    'opening_balance'       => 'Početni saldo',
    'current_balance'       => 'Trenutni saldo',
    'bank_name'             => 'Naziv banke',
    'bank_phone'            => 'Telefon banke',
    'bank_address'          => 'Adresa banke',
    'default_account'       => 'Zadani račun',

];
