<?php

return [

    'error' => [
        'not_user_dashboard'    => 'Pogreška: Nije vam dopušteno mijenjati ovu nadzornu ploču!',
        'delete_last'           => 'Pogreška: Ne može se izbrisati zadnja nadzorna ploča. Prvo stvorite novu!',
        'disable_last'          => 'Pogreška: Ne može se izbrisati zadnja nadzorna ploča. Prvo stvorite novu!',
    ],

];
