<?php

return [

    'can_login'             => 'Možete li se prijaviti?',
    'user_created'          => 'Korisnik kreiran',

    'error' => [
        'email'             => 'E-mail je već zauzet.',
    ],

];
