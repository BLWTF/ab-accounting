<?php

return [

    'domain'                => 'Domena',
    'logo'                  => 'Logo',

    'error' => [
        'not_user_company'  => 'Pogreška: Nije vam dopušteno mijenjati ovu kompaniju!',
        'delete_active'     => 'Pogreška: Aktivno poduzeće nije moguće izbrisati. Molimo da najprije prijeđete na sljedeću!',
        'disable_active'    => 'Pogreška: Ne može se onemogućiti aktivna kompanija. Molimo da je najprije promijenite!',
    ],

];
