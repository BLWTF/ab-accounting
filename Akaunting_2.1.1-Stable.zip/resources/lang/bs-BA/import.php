<?php

return [

    'import'                => 'Uvezi',
    'title'                 => 'Uvoz :type',
    'message'               => 'Dopušteni tipovi datoteka: XLS, XLSX. Molimo,, <a target="_blank" href=":link"><strong>preuzmite</strong></a> primjer datoteke.',

];
