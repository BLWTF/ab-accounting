<?php

return [

    'from_account'          => 'S računa',
    'to_account'            => 'Na račun',

    'messages' => [
        'delete'            => ':from za :to (:amount)',
    ],

];
