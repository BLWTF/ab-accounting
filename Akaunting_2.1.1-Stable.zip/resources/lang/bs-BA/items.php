<?php

return [

    'sales_price'           => 'Prodajna cijena',
    'purchase_price'        => 'Kupovna cijena',

];
