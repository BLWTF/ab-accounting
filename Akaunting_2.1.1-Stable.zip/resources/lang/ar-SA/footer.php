<?php

return [

    'version'               => 'إصدار',
    'powered'               => 'بواسطة أكاونتينج',
    'link'                  => 'https://akaunting.com',
    'software'              => 'برنامج محاسبي مجاني',

];
