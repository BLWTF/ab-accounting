<?php

return [

    'reconcile'             => 'التسوية',
    'reconciled'            => 'تمت التسوية',
    'closing_balance'       => 'الرصيد الختامي',
    'unreconciled'          => 'لم تتم التسوية',
    'transactions'          => 'المعاملات',
    'start_date'            => 'تاريخ البدء',
    'end_date'              => 'تاريخ الانتهاء',
    'cleared_amount'        => 'صافي القيمة',
    'deposit'               => 'إيداع',
    'withdrawal'            => 'سحب',

];
