<?php

return [

    'import'                => 'استيراد',
    'title'                 => 'استيراد :type',
    'message'               => 'أنواع الملفات المسموحة: XLS, XLSX. من فضلك قم <a target="_blank" href=":link"><strong>بتحميل</strong></a> ملفاً لرؤية مثال على ذلك.',

];
