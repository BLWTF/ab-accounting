<?php

return [

    'sales_price'           => 'سعر البيع',
    'purchase_price'        => 'سعر الشراء',

];
