<?php

return [

    'whoops'              => 'Whoops!',
    'hello'               => 'Hola!',
    'salutation'          => 'Atentament,<br> :company_name',
    'subcopy'             => 'Si tens problemes quan prems el botó ":text", copia i enganxa l\'enllaç de sota al teu navegador: [:url](:url)',

];
