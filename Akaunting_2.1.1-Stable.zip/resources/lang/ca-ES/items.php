<?php

return [

    'sales_price'           => 'Preu de venda',
    'purchase_price'        => 'Preu de compra',

];
