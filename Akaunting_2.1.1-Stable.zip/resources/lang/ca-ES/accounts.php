<?php

return [

    'account_name'          => 'Nom del compte',
    'number'                => 'Número',
    'opening_balance'       => 'Balanç inicial',
    'current_balance'       => 'Balanç actual',
    'bank_name'             => 'Nom del banc',
    'bank_phone'            => 'Telèfon del banc',
    'bank_address'          => 'Adreça del banc',
    'default_account'       => 'Compte per defecte',

];
