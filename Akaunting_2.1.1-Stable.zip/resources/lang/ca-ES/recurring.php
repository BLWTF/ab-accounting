<?php

return [

    'recurring'             => 'Recurrent',
    'every'                 => 'Cada',
    'period'                => 'Període',
    'times'                 => 'Vegades',
    'daily'                 => 'Diàriament',
    'weekly'                => 'Setmanalment',
    'monthly'               => 'Mensualment',
    'yearly'                => 'Anualment',
    'custom'                => 'Personalitzat',
    'days'                  => 'Die(s)',
    'weeks'                 => 'Setmana(es)',
    'months'                => 'Mes(os)',
    'years'                 => 'Any(s)',
    'message'               => 'Això és :type recurrent i el següent :type es generarà automàticament el :date',

];
