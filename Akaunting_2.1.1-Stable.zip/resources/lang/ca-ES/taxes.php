<?php

return [

    'rate'                  => 'Taxa',
    'rate_percent'          => 'Taxa (%)',
    'normal'                => 'Normal',
    'inclusive'             => 'Inclusiu',
    'compound'              => 'Compost',
    'fixed'                 => 'Fix',
    'withholding'           => 'Retenció',
];
