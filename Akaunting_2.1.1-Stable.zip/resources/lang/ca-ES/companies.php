<?php

return [

    'domain'                => 'Domini',
    'logo'                  => 'Logotip',

    'error' => [
        'not_user_company'  => 'Error: No tens permisos per modificar aquesta companyia!',
        'delete_active'     => 'Error: No es pot esborrar la companyia activa. Si us plau, canvia primer a una altra companyia.',
        'disable_active'    => 'Error: No es pot desactivar la companyia activa. Si us plau, canvia primer a una altra companyia.',
    ],

];
