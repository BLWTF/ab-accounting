<?php

return [

    'version'               => 'Versió',
    'powered'               => 'Powered by Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Programari lliure de Facturació/Comptabilitat',

];
