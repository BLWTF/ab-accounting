<?php

return [

    'reconcile'             => 'Concilia',
    'unreconcile'           => 'Desfés la conciliació',
    'reconciled'            => 'Torna a conciliar',
    'opening_balance'       => 'Balanç d\'obertura',
    'closing_balance'       => 'Balanç de tancament',
    'unreconciled'          => 'No conciliat',
    'transactions'          => 'Transacció',
    'start_date'            => 'Data d\'inici',
    'end_date'              => 'Data de fi',
    'cleared_amount'        => 'Quantitat esborrada',
    'deposit'               => 'Dipòsit',
    'withdrawal'            => 'Retirada',

];
