<?php

return [

    'import'                => 'Importa',
    'title'                 => 'Importa :type',
    'message'               => 'Tipus de fitxers permesos: XLS, XLSX. Si us plau, <a target="_blank" href=":link"><strong>descarrega</strong></a> el fitxer de mostra.',

];
