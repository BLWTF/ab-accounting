<?php

return [

    'recurring'             => 'Opakující se',
    'every'                 => 'Každý',
    'period'                => 'Období',
    'times'                 => 'Krát',
    'daily'                 => 'Denně',
    'weekly'                => 'Týdně',
    'monthly'               => 'Měsíčně',
    'yearly'                => 'Ročně',
    'custom'                => 'Vlastní',
    'days'                  => 'Dnů(í)',
    'weeks'                 => 'Týden(Týdny)',
    'months'                => 'Měsíc(e)',
    'years'                 => 'Rok(y)',
    'message'               => 'Toto je opakovaný :type. Další :type bude automaticky generován dne :date',

];
