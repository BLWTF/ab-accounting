<?php

return [

    'domain'                => 'Doména',
    'logo'                  => 'Logo',

    'error' => [
        'not_user_company'  => 'Chyba: pro úpravu společností nemáte oprávnění!',
        'delete_active'     => 'Chyba: Nejde smazat aktivní společnost. Nejdřív ji změňte!',
        'disable_active'    => 'Chyba: Nelze vypnout aktivní společnost. Nejprve, prosím, přepněte na jinou společnost!',
    ],

];
