<?php

return [

    'sales_price'           => 'Prodejní cena',
    'purchase_price'        => 'Nákupní cena',

];
