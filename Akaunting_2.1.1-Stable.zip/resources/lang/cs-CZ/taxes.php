<?php

return [

    'rate'                  => 'Sazba',
    'rate_percent'          => 'Sazba (%)',
    'normal'                => 'Normální',
    'inclusive'             => 'Daň zahrnuta',
    'compound'              => 'Složená daň',
    'fixed'                 => 'Pevné',
    'withholding'           => 'Srážková daň u zdroje',
];
