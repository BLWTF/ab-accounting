<?php

return [

    'error' => [
        'not_user_dashboard'    => 'Chyba: Nemáte oprávnění měnit tento dashboard!',
        'delete_last'           => 'Chyba: Nelze odstranit poslední dashboard. Nejdříve, prosím, vytvořte nový!',
        'disable_last'          => 'Chyba: Nelze odstranit poslední dashboard. Nejdříve, prosím, vytvořte nový!',
    ],

];
