<?php

return [

    'installed_version'     => 'Nainstalovaná verze',
    'latest_version'        => 'Nejnovější verze',
    'update'                => 'Aktualizovat Akaunting na verzi :version',
    'changelog'             => 'Seznam změn',
    'check'                 => 'Zkontrolovat',
    'new_core'              => 'K dispozici je aktualizovaná verze Akaunting.',
    'latest_core'           => 'Blahopřejeme! Máte nejnovější verzi Akaunting. Budoucí aktualizace budou nainstalovány automaticky.',
    'success'               => 'Proces aktualizace byl úspěšně dokončen.',
    'error'                 => 'Proces aktualizace se nezdařil, prosím, zkuste to znovu.',

];
