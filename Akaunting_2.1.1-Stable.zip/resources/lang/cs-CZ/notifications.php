<?php

return [

    'whoops'              => 'Jejda!',
    'hello'               => 'Ahoj!',
    'salutation'          => 'S pozdravem,<br> :company_name',
    'subcopy'             => 'Pokud vám nefunguje tlačítko ":text", zkopírujte a vložte adresu URL do prohlížeče: [:url](:url)',

];
