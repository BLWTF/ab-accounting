<?php

return [

    'import'                => 'Importovat',
    'title'                 => 'Import :type',
    'message'               => 'Povolené typy: CSV, XLS. Prosím, <a target="_blank" href=":link"><strong>stáhněte</strong></a> si vzorový soubor.',

];
