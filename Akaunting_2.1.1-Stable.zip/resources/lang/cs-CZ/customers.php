<?php

return [

    'can_login'             => 'Může se přihlásit?',
    'user_created'          => 'Uživatel byl vytvořen',

    'error' => [
        'email'             => 'Tato e-mailová adresa je již obsazena.',
    ],

];
