<?php

return [

    'rate'                  => 'Sats',
    'rate_percent'          => 'Sats (%)',
    'normal'                => 'Normal',
    'inclusive'             => 'Inklusiv',
    'compound'              => 'Sammensatte',
    'fixed'                 => 'Fast',
    'withholding'           => 'Tilbageholdt',
];
