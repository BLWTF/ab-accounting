<?php

return [

    'error' => [
        'not_user_dashboard'    => 'Fejl: Du har ikke lov til at ændre dette skrivebord!',
        'delete_last'           => 'Fejl: Kan ikke slette de sidste skrivebord. Venligst, opret et nyt et først!',
        'disable_last'          => 'Fejl: Kan ikke deaktivere det sidste skrivebord. Venligst, opret et nyt først!',
    ],

];
