<?php

return [

    'can_login'             => 'Kan logge ind?',
    'user_created'          => 'Bruger oprettet',

    'error' => [
        'email'             => 'Denne mail er allerede registreret.',
    ],

];
