<?php

return [

    'version'               => 'Version',
    'powered'               => 'Drevet af Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Gratis regnskabsprogram',

];
