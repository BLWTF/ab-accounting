<?php

return [

    'recurring'             => 'Gentagende',
    'every'                 => 'Hver',
    'period'                => 'Periode',
    'times'                 => 'Gange',
    'daily'                 => 'Daglig',
    'weekly'                => 'Ugentlig',
    'monthly'               => 'Månedlig',
    'yearly'                => 'Årlig',
    'custom'                => 'Tilpasset',
    'days'                  => 'Dag(e)',
    'weeks'                 => 'Uge(r)',
    'months'                => 'Måned(er)',
    'years'                 => 'År',
    'message'               => 'Dette er en tilbagevendende :type og den næste vil blive autogenereret den :date',

];
