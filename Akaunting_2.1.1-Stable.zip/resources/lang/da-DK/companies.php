<?php

return [

    'domain'                => 'Domæne',
    'logo'                  => 'Logo',

    'error' => [
        'not_user_company'  => 'Fejl: Du har ikke tilladelse til at ændre denne virksomhed!',
        'delete_active'     => 'Fejl: Kan ikke slette det aktive selskab. Venligst, skift til et andet først!',
        'disable_active'    => 'Fejl: Kan ikke deaktivere det aktive selskab. Venligst, skift til et andet først!',
    ],

];
