<?php

return [

    'previous'              => 'Forrige',
    'next'                  => 'Næste',
    'showing'               => ':first-:last af :total poster.',
    'page'                  => 'pr side.',

];
