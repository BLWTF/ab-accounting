<?php

return [

    'reconcile'             => 'সমন্বয়',
    'reconciled'            => 'সমন্বয়কৃত',
    'closing_balance'       => 'অবসান স্থিতি',
    'unreconciled'          => 'সমন্বয়কৃত নয়',
    'transactions'          => 'লেনদেনসমূহ',
    'start_date'            => 'শুরুর তারিখ',
    'end_date'              => 'শেষের তারিখ',
    'cleared_amount'        => 'অবমুক্ত ',
    'deposit'               => 'আমানত',
    'withdrawal'            => 'উত্তোলন',

];
