<?php

return [

    'import'                => 'Εισαγωγή',
    'title'                 => 'Εισαγωγή :type',
    'message'               => 'Επιτρεπόμενοι τύποι αρχείων: XLS, XLSX. Παρακαλούμε, <a target="_blank" href=":link"><strong>Κατεβάστε</strong></a> το διαθέσιμο παράδειγμα.',

];
