<?php

return [

    'accounts_cash'         => 'Μετρητά',
    'categories_deposit'    => 'Κατάθεση',
    'categories_sales'      => 'Πωλήσεις',
    'currencies_usd'        => 'Δολάριο ΗΠΑ',
    'currencies_eur'        => 'Ευρώ',
    'currencies_gbp'        => 'Βρετανική Λίρα',
    'currencies_try'        => 'Τουρκική Λίρα',

];
