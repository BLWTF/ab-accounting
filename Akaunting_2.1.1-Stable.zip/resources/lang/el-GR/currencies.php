<?php

return [

    'code'                  => 'Κωδικός',
    'rate'                  => 'Ποσοστό',
    'default'               => 'Προεπιλεγμένο νόμισμα',
    'decimal_mark'          => 'Υποδιαστολή',
    'thousands_separator'   => 'Σύμβολο διαχωρισμού χιλιάδων',
    'precision'             => 'Ακρίβεια',
    'symbol' => [
        'symbol'            => 'Σύμβολο',
        'position'          => 'Θέση συμβόλου',
        'before'            => 'Πριν από το ποσό',
        'after'             => 'Μετά από το ποσό',
    ]

];
