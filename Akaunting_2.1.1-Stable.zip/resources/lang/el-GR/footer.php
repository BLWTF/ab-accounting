<?php

return [

    'version'               => 'Έκδοση',
    'powered'               => 'Powered By Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Δωρεάν λογισμικό λογιστικής',

];
