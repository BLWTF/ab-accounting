<?php

return [

    'styles' => [
        'argon' => \Akaunting\Menu\Presenters\Admin\Argon::class,
    ],

    'home_urls' => [
        '/',
        'portal',
    ],

    'ordering' => true,

];
