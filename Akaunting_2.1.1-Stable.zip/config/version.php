<?php

return [

    'name'      =>  'Akaunting',

    'code'      =>  'Document',

    'major'     =>  '2',

    'minor'     =>  '1',

    'patch'     =>  '1',

    'build'     =>  '',

    'status'    =>  'Stable',

    'date'      =>  '1-February-2020',

    'time'      =>  '11:00',

    'zone'      =>  'GMT +3',

];
